#include "stm32f4xx_hal.h"

void pn(void);
void delay(volatile int time);

int main()
{
	pn();
	while(1)
	{
		HAL_GPIO_TogglePin (GPIOG,GPIO_PIN_13|GPIO_PIN_14);
		delay(2000);
	}
}

void pn(void)
{
	__HAL_RCC_GPIOG_CLK_ENABLE();
	GPIO_InitTypeDef p;
	p.Mode=GPIO_MODE_OUTPUT_PP;
	p.Pin=GPIO_PIN_13|GPIO_PIN_14;
	HAL_GPIO_Init(GPIOG,&p);
}

void delay(volatile int time)
{
	for(int i=0;i<time*1000;i++)
	{}
}
